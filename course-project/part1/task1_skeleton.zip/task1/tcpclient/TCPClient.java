package tcpclient;
import java.net.*;
import java.io.*;

public class TCPClient {
    
    public static String askServer(String hostname, int port, String ToServer) throws IOException {
        return null;
    }

    public static String askServer(String hostname, int port) throws IOException {
        return null;
    }
}

